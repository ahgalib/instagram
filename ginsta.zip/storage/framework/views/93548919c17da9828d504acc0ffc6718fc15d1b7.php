<?php $__env->startSection('title'); ?><?php echo e($user->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="profile_page">
    <div class="container">
        <div class="profile_section">

            <div class="profile_header">
                <div class="profile_header_image">
                    <?php if($user->profile->image): ?>
                        <img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($user->profile->image); ?>" alt="">
                    <?php else: ?>
                        <img src="<?php echo e(Avatar::create(auth()->user()->name)->toBase64()); ?>" alt="">
                    <?php endif; ?>
                </div>
                <div class="profile_header_info">
                    <div class="name_info">
                        <h3><?php echo e($user->username); ?></h3>
                        <?php if(auth::user()->id == $user->id): ?>
                        <a href="/profile/<?php echo e($user->id); ?>/edit"><button class="btn btn-light">Edit profile</button></a>
                        <?php else: ?>
                            <?php if(!$user->profile->followedBy(auth()->user())): ?>
                                <div style="margin-right:10px;">
                                    <form action="<?php echo e(route('user.following',$user->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit"class="btn btn-primary btn-sm">follow</button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <div style="margin-right:200px;">
                                    <form action="<?php echo e(route('user.unfollow',$user->profile->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit"class="btn btn-dark btn-sm">Unfollow</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <a href="/setting"><button class="btn btn-secondary p-2" style="margin-left:45px;">Setting</button></a>

                    </div>
                    <div class="post_follower_info">
                        <p><strong><?php echo e($user->posts->count()); ?> </strong> posts</p>
                        <p><strong><?php echo e($user->profile->follow->count()); ?> </strong> followers</p>
                        <p><strong><?php echo e($user->following->count()); ?> </strong> following</p>
                    </div>
                    <div class="caption_info">
                        <h4><?php echo e($user->name); ?></h4>
                        <p><?php echo e($user->profile->title); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="post_section">
            <div class="add_post_div">
                <p class="post_section_p">posts</p>
                <?php if(auth::user()->id == $user->id): ?>
                    <a href="/addpost"><button class="btn btn-light">add post</button></a>
                <?php endif; ?>

            </div>

            <div class="post_image_section">
                <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single_post">
                        <div class="single_post_image">
                            <img src="<?php echo e(asset('uploads/posts/')); ?>/<?php echo e($post->image); ?>" alt="">
                        </div>
                        <div class="single_post_like">
                            <?php if(!$post->likedBy(auth::user())): ?>
                                <form action="/post/<?php echo e($post->id); ?>/like" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"  class="fa-regular fa-heart" style="border:none;font-size:25px;"> </button>
                                    <i class="fa-regular fa-comment"></i>
                                    <i class="fa-regular fa-paper-plane"></i>
                                </form>
                            <?php else: ?>
                                <form action="/post/<?php echo e($post->id); ?>/unlike" method="post">
                                <?php echo csrf_field(); ?>
                                    <button type="submit"  class="fa-regular fa-heart red" style="border:none;font-size:25px;color:red;"> </button>
                                    <a href="/post/comment/<?php echo e($post->id); ?>"><i class="fa-regular fa-comment"></i></a>
                                    <i class="fa-regular fa-paper-plane"></i>
                                </form>
                            <?php endif; ?>

                        </div>
                        <div class="like_count">
                            <?php if($post->like->count()==0): ?>
                                <p>no one like this</p>
                            <?php elseif($post->like->count() == 1 && $post->likedBy(auth::user())): ?>
                                <p>you <span style="color:red;">liked </span> this</p>
                            <?php elseif($post->like->count() ==2 && $post->likedBy(auth::user())): ?>
                                <p>you and <?php echo e($post->like->count()-1); ?> other <span style="color:red;">liked </span> this </p>
                            <?php else: ?>
                                <p><?php echo e($post->like->count()); ?> likes</p>
                            <?php endif; ?>
                        </div>

                        <div class="comment_count" style="margin-bottom:5px;">
                            <?php if($post->comment->count()==0): ?>
                                <p><a href="/post/comment/<?php echo e($post->id); ?>">no comment yet </a></p>
                            <?php elseif($post->comment->count() == 1): ?>
                                <p><a href="/post/comment/<?php echo e($post->id); ?>">1 comment only </a></p>

                            <?php else: ?>
                                <p><a href="/post/comment/<?php echo e($post->id); ?>"><?php echo e($post->comment->count()); ?> comments </a></p>
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div>



<div class="phone_view">
   <!-- Example split danger button -->
   <div class="phone_view_header">
        <div class="btn-group front_header_content">
            <button type="button" class="instagram_button">Instagram</button>
            <button type="button" class="dropdown-toggle dropdown-toggle-split instagram_button_droupdown" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="visually-hidden">Toggle Dropdown</span>
            </button>
            <ul class="dropdown-menu droupdown_ul">
                <li class="droupdown_li"><a class="dropdown-item" href="#">Action</a></li>

                <?php if(auth::user()->id == $user->id): ?>
                    <li class="droupdown_li"><a class="dropdown-item" href="/profile/<?php echo e($user->id); ?>/edit">Edit Profile</a></li>
                    <li class="droupdown_li"><a class="dropdown-item" href="/addpost">Add post</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <div class="phone_header">


        <div class="p_h_profile_pic">
           <div class="main_p_pic">
            <?php if($user->profile->image): ?>
                <img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($user->profile->image); ?>" alt="">
            <?php else: ?>
                <img src="<?php echo e(Avatar::create(auth()->user()->name)->toBase64()); ?>" alt="">
            <?php endif; ?>
           </div>

        </div>
        <div class="p_h_profile_info">
            <div class="posts_info"><p><h6><?php echo e($user->posts->count()); ?> </h6> posts</p></div>
            <div class="follow_info"> <p><h6><?php echo e($user->profile->follow->count()); ?> </h6> followers</p></div>
            <div class="followers_info"><p><h6><?php echo e($user->following->count()); ?> </h6> following</p></div>

        </div>
    </div>
    <div class="p_h_bio">
        <div class="bio_content">
            <h4><?php echo e($user->name); ?></h4>
            <p><?php echo e($user->profile->title); ?></p>
        </div>
        <div class="follow_content">
            <?php if(auth::user()->id == $user->id): ?>

            <?php else: ?>
                <?php if(!$user->profile->followedBy(auth()->user())): ?>
                    <div style="margin-right:10px;">
                        <form action="<?php echo e(route('user.following',$user->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit"class="btn btn-primary btn-sm">follow</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div style="margin-right:200px;">
                        <form action="<?php echo e(route('user.unfollow',$user->profile->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit"class="btn btn-dark btn-sm">Unfollow</button>
                        </form>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="phone_profile_body">
        <h5>posts</h5>
        <div class="p_h_profile_images">
            <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p_h_single_post">
                <div class="p_h_single_post_image">
                    <img src="<?php echo e(asset('uploads/posts')); ?>/<?php echo e($post['image']); ?>" alt="">
                </div>
                <div class="p_h_single_post_like">
                    <?php if(!$post->likedBy(auth::user())): ?>
                        <form action="/post/<?php echo e($post->id); ?>/like" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit"  class="fa-regular fa-heart" style="border:none;font-size:12px;margin-right:7px;"> </button>
                            <i class="fa-regular fa-comment"></i>
                            <i class="fa-regular fa-paper-plane"></i>
                        </form>
                    <?php else: ?>
                        <form action="/post/<?php echo e($post->id); ?>/unlike" method="post">
                        <?php echo csrf_field(); ?>
                            <button type="submit"  class="fa-regular fa-heart red" style="border:none;font-size:12px;margin-right:7px;color:red;"> </button>
                            <a href="/post/comment/<?php echo e($post->id); ?>"><i class="fa-regular fa-comment"></i></a>
                            <i class="fa-regular fa-paper-plane"></i>
                        </form>
                    <?php endif; ?>

                </div>
                <div class="p_h_like_count">
                    <?php if($post->like->count()==0): ?>
                        <p>no one like this</p>
                    <?php elseif($post->like->count() == 1 && $post->likedBy(auth::user())): ?>
                        <p>you <span style="color:red;">liked </span> this</p>
                    <?php elseif($post->like->count() ==2 && $post->likedBy(auth::user())): ?>
                        <p>you and <?php echo e($post->like->count()-1); ?> other <span style="color:red;">liked </span> this </p>
                    <?php else: ?>
                        <p><?php echo e($post->like->count()); ?> likes</p>
                    <?php endif; ?>
                </div>

                <div class="p_h_comment_count" style="margin-bottom:5px;">
                    <?php if($post->comment->count()==0): ?>
                        <p><a href="/post/comment/<?php echo e($post->id); ?>">no comment yet </a></p>
                    <?php elseif($post->comment->count() == 1): ?>
                        <p><a href="/post/comment/<?php echo e($post->id); ?>">1 comment only </a></p>

                    <?php else: ?>
                        <p><a href="/post/comment/<?php echo e($post->id); ?>"><?php echo e($post->comment->count()); ?> comments </a></p>
                    <?php endif; ?>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Instagram\resources\views/home.blade.php ENDPATH**/ ?>