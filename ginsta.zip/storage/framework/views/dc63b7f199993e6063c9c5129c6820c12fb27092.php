<?php $__env->startSection('title'); ?><?php echo e('Add Post'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container add_post_con">
   <form action="/createpost" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center mt-5">

            <div class="col-md-8 m-2 mt-4">
                <h3 class="mb-4">Add a Post</h3>
                <div class="form-group row m-3 mt-4">
                    Enter caption for your image
                    <label for="caption" class="col-md-4 col-form-label"></label>

                    <div class="col-md-8">
                        <textarea name="caption" id="caption" cols="30" rows="5" class="form-control <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('caption')); ?></textarea>


                        <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color:red;"><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- image -->
                <div class="form-group row m-3">
                    Enter caption for your image
                    <label for="image" name="image" class="col-md-4 col-form-label"></label>

                    <div class="col-md-8">
                        <input type="file" name="image" id="image"class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span>
                                <strong style="color:red;"><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <button type="submit"class="btn btn-danger m-3">Upload</button>
            </div>

        </div>
   </form>
</div>


<div class="addpost_responsive_container">
    <form action="/createpost" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="row justify-content-center">

             <div class="col-md-8 m-2 mt-4">
                 <h3 class="mb-4">Add a Post</h3>
                 <div class="form-group row m-3 mt-4">
                     Enter caption for your image
                     <label for="caption" class="col-md-4 col-form-label"></label>

                     <div class="col-md-8">
                         <textarea name="caption" id="caption" cols="30" rows="5" class="form-control <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('caption')); ?></textarea>


                         <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="invalid-feedback" role="alert">
                                 <strong style="color:red;"><?php echo e($message); ?></strong>
                             </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>
                 <!-- image -->
                 <div class="form-group row m-3">
                     Enter caption for your image
                     <label for="image" name="image" class="col-md-4 col-form-label"></label>

                     <div class="col-md-8">
                         <input type="file" name="image" id="image"class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                         <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span>
                                 <strong style="color:red;"><?php echo e($message); ?></strong>
                             </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>
                 <button type="submit"class="btn btn-danger btn-sm m-3 mb-5">Upload</button>
             </div>

         </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Instagram\resources\views/addpost/post.blade.php ENDPATH**/ ?>