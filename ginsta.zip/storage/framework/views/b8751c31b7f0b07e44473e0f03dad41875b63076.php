<?php $__env->startSection('title'); ?><?php echo e('Comment'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="comment_section">
        <div class="comment_content">
            <div class="header_section">
                <?php if($post->user->profile->image): ?>
                    <a href="/user/<?php echo e($post->user->id); ?>"><img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($post->user->profile->image); ?>" alt="" class="profile_image"></a>
                <?php else: ?>
                    <a href="/user/<?php echo e($post->user->id); ?>"><img src="<?php echo e(Avatar::create($post->user->name)->toBase64()); ?>" alt="pp" class="profile_image"></a>

                <?php endif; ?>
                <a href="/user/<?php echo e($post->user->id); ?>"><h3><?php echo e($post->user->name); ?></h3></a>
                <p> <?php echo e($post->created_at->diffForHumans()); ?></p>
            </div>
            <div class="body_section">
                <img src="<?php echo e(asset('uploads/posts')); ?>/<?php echo e($post->image); ?>" alt="" class="comment_upload_image">
            </div>
            <div class="footer_section">
                <div class="like_part">
                    <?php if(!$post->likedBy(auth::user())): ?>
                        <form action="/post/<?php echo e($post->id); ?>/like" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit"  class="fa-regular fa-heart" style="border:none;font-size:25px;margin-right:30px;"> </button>
                        </form>
                    <?php else: ?>
                        <form action="/post/<?php echo e($post->id); ?>/unlike" method="post">
                        <?php echo csrf_field(); ?>
                            <button type="submit"  class="fa-regular fa-heart red" style="border:none;font-size:25px;color:red;margin-right:30px;"> </button>
                        </form>
                    <?php endif; ?>
                    <a href="/post/comment/<?php echo e($post->id); ?>"><i class="fa-regular fa-comment"></i></a>
                    <i class="fa-regular fa-paper-plane"></i>
                </div>
                <div class="like_count">
                    <?php if($post->like->count()==0): ?>
                        <p>no one like this</p>
                    <?php elseif($post->like->count() == 1 && $post->likedBy(auth::user())): ?>
                        <p>you <span style="color:red;">liked </span> this</p>
                    <?php elseif($post->like->count() ==2 && $post->likedBy(auth::user())): ?>
                        <p>you and <?php echo e($post->like->count()-1); ?> other <span style="color:red;">liked </span> this </p>
                    <?php else: ?>
                        <p><?php echo e($post->like->count()); ?> likes</p>
                    <?php endif; ?>
                </div>
                <div class="caption_section">
                    <h4><?php echo e($post->user->name); ?></h4>
                    <p><?php echo e($post->caption); ?></p>
                </div>
                <div class="comment_area">

                    <div class="comment_user_profile">
                        <a href="/user/<?php echo e($post->user->id); ?>"><img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($post->user->profile->image); ?>" alt="" class="comment_profile_image"></a>
                    </div>
                    <form action="<?php echo e(route('comment.create')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="comment_input">
                            <input type="hidden" name="post_id" value=<?php echo e($post->id); ?>>
                            <input type="text" class="comment_input" name="comment" placeholder="leave a comment">
                            <button class="btn-comment">comment</button>
                        </div>
                    </form>
                </div>
                <div>
                    <h5 class="comment_count"><?php echo e($comments->count()); ?> Comment </h5>
                </div>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="show_comment_area">
                        <div class="comment_user_profile">
                            <?php if($comment->user->profile->image): ?>
                                <a href="/user/<?php echo e($comment->user->id); ?>"><img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($comment->user->profile->image); ?>" alt="" class="comment_profile_image"></a>
                            <?php else: ?>
                                <a href="/user/<?php echo e($comment->user->id); ?>"><img src="<?php echo e(Avatar::create($comment->user->name)->toBase64()); ?>" alt="pp" class="profile_image"></a>
                            <?php endif; ?>

                        </div>

                        <form action="<?php echo e(route('comment.create')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="comment_body">
                                <div class="comment_header">
                                    <h5><?php echo e($comment->user->name); ?></h5>
                                    <p><?php echo e($comment->comment); ?></p>
                                </div>
                                <a href="#reply" class="reply" data-parent=<?php echo e($comment->id); ?>>reply</a>
                            </div>
                    </div>
                    <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="show_comment_area" style="margin-left:15%;width:80%;">
                            <div class="comment_user_profile">


                                <?php if($reply->user->profile->image): ?>
                                    <a href="/user/<?php echo e($reply->user->id); ?>"><img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($reply->user->profile->image); ?>" alt="" class="comment_profile_image"></a>
                                <?php else: ?>
                                    <a href="/user/<?php echo e($reply->user->id); ?>"><img src="<?php echo e(Avatar::create($reply->user->name)->toBase64()); ?>" alt="" class="comment_profile_image"></a>
                                <?php endif; ?>
                            </div>

                            
                                <div class="comment_body">
                                    <div class="comment_header">
                                        <h5><?php echo e($reply->user->name); ?></h5>
                                        <p><?php echo e($reply->comment); ?></p>
                                    </div>
                                    <a href="#reply" class="reply" data-parent=<?php echo e($comment->id); ?>>reply</a>
                                </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="reply-div" id="reply">
                    <input type="hidden" name="post_id" value=<?php echo e($post->id); ?>>
                    <input type="hidden" name="parent_id" class="parent">
                    <input type="text" name="comment" placeholder="reply">
                    <button class="reply-submit">submit</button>
                </div>
                            </form>
                            
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Instagram\resources\views/comment.blade.php ENDPATH**/ ?>