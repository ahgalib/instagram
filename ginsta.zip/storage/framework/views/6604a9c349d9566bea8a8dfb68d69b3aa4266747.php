
<?php $__env->startSection('title'); ?><?php echo e('Instagram'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
       <div class="col-md-6 m-auto">
           <h2 style="font-family:Comic Sans MS;">Welcome to <span style="color:orangered;font-weight:bold;">Instagram</span></h2>
       </div>
   </div>
   <div class="row p-4">
       <div class="col-md-8 m-auto">
            <div>
                <img src="image/168908.jpg" alt="" style="width:600px;">
            </div>
            
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Instagram\resources\views/page.blade.php ENDPATH**/ ?>