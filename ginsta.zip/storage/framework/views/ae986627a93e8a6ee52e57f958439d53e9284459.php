<?php $__env->startSection('title'); ?><?php echo e('ImageFeed'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="header-responsive">
    <div class="logo">
        <p><a href="/">Instagram</a></p>
    </div>
    <div class="icon">
        <ul>
            <li><i class="fa-regular fa-message"></i></li>
            <li><i class="fa-regular fa-heart"></i></li>
        </ul>
    </div>
</div>

<div class="newsfeed_section">

    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="main_seciton">
            <div class="header_section">
                <?php if($posts->user->profile->image): ?>
                    <a href="/user/<?php echo e($posts->user->id); ?>"><img src="<?php echo e(asset('uploads/profile')); ?>/<?php echo e($posts->user->profile->image); ?>" alt="" class="profile_image"></a>
                <?php else: ?>
                    <img src="<?php echo e(Avatar::create($posts->user->name)->toBase64()); ?>" alt="" class="profile_image">
                <?php endif; ?>
                <a href="/user/<?php echo e($posts->user->id); ?>"><h3><?php echo e($posts->user->name); ?></h3></a>
                <p> <?php echo e($posts->created_at->diffForHumans()); ?></p>
            </div>
            <div class="body_section">
                <img src="<?php echo e(asset('uploads/posts')); ?>/<?php echo e($posts->image); ?>" alt="" class="upload_image">
            </div>
            <div class="footer_section">
                <div class="like_part">
                    <?php if(!$posts->likedBy(auth::user())): ?>
                        <form action="/post/<?php echo e($posts->id); ?>/like" method="post">
                            <?php echo csrf_field(); ?>
                                <button type="submit"  class="fa-regular fa-heart like" data-post="<?php echo e($posts->id); ?>" style="border:none;font-size:25px;margin-right:30px;"> </button>
                        </form>
                    <?php else: ?>
                        <form action="/post/<?php echo e($posts->id); ?>/unlike" method="post">
                        <?php echo csrf_field(); ?>
                            <button type="submit"  class="fa-regular fa-heart red unlike" data-post="<?php echo e($posts->id); ?>" style="border:none;font-size:25px;color:red;margin-right:30px;"> </button>

                        </form>
                    <?php endif; ?>
                    <a href="/post/comment/<?php echo e($posts->id); ?>"><i class="fa-regular fa-comment"></i></a>
                    <i class="fa-regular fa-paper-plane"></i>
                </div>
                <div class="like_count">
                    <?php if($posts->like->count()==0): ?>
                        <p>no one like this</p>
                    <?php elseif($posts->like->count() == 1 && $posts->likedBy(auth::user())): ?>
                        <p class="normal-like">you <span style="color:red;">liked </span> this</p>

                    <?php elseif($posts->like->count() ==2 && $posts->likedBy(auth::user())): ?>
                        <p>you and <?php echo e($posts->like->count()-1); ?> other <span style="color:red;">liked </span> this </p>
                    <?php else: ?>
                        <p><?php echo e($posts->like->count()); ?> likes</p>
                    <?php endif; ?>
                </div>
                <div class="caption_section">
                    <h4><?php echo e($posts->user->name); ?></h4>
                    <p><?php echo e($posts->caption); ?></p>
                </div>
                <div class="view_comment">
                    <?php if($posts->comment->count() == 0): ?>
                        <p>No comments yet</p>
                    <?php elseif($posts->comment->count() == 1): ?>
                        <p><a href="/post/comment/<?php echo e($posts->id); ?>">1 comment only </a></p>
                    <?php else: ?>
                        <p><a href="/post/comment/<?php echo e($posts->id); ?>"> View all <?php echo e($posts->comment->count()); ?> comments </a></p>
                    <?php endif; ?>
                    <p>Add a comment</p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Instagram\resources\views/imagefeed.blade.php ENDPATH**/ ?>