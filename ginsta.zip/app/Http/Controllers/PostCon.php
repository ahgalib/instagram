<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
use App\Models\Like;
use Auth;

class PostCon extends Controller
{
    public function index(){
        return view('addpost.post');
    }
    public function show(Post $post){
        return view('show',compact('post'));
    }

    public function like($id,Request $request,Post $post){
        //dd($post->likedBy($id));
        Like::create([
            'user_id'=>$request->user()->id,
            'post_id'=>$id,
        ]);
        return redirect()->back();
    }

    public function unlike($id,Request $request){
        $request->user()->like()->where('post_id',$id)->delete();
        return redirect()->back();
    }

    public function ajax_like(Request $request){
        //echo "heooloow this is wokrj";
        Like::create([
            'user_id'=>Auth::id(),
            'post_id'=>$request->postId,
        ]);

        $unlike = '<button type="submit" class="fa-regular fa-heart red unlike" data-post="{{$posts->id}}" style="border:none;font-size:25px;color:red;margin-right:30px;"></button>';
        // $unlike .= 'you <span style="color:red;">liked </span> this';
        echo $unlike;
        //echo $like_count;

    }

}
