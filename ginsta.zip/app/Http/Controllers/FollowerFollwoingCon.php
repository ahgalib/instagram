<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Follower;
class FollowerFollwoingCon extends Controller
{
    function store(User $user,Request $req){
       // dd($user->followedBy($req->user()));
        $user->follow()->create([
            'profile_id'=>$req->user()->id,
        ]);
        return back();
    }

    function unfollow(Request $req,$profile){
        // dd($user->followedBy($req->user()));
        Follower::where('profile_id',$profile)->delete();
         return back();
     }
}
